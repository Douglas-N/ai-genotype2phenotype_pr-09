import torch
from torch.utils.data import DataLoader, TensorDataset
from models import MultiModalModel

# Placeholder data
expr = torch.randn(100, 1000)
mut = torch.randn(100, 500)
comp = torch.randn(100, 256)
y = torch.randn(100,1)

dataset = TensorDataset(expr, mut, comp, y)
loader = DataLoader(dataset, batch_size=16, shuffle=True)

model = MultiModalModel()
criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

for epoch in range(5):
    for batch in loader:
        e, m, c, target = batch
        optimizer.zero_grad()
        out = model(e, m, c)
        loss = criterion(out, target)
        loss.backward()
        optimizer.step()
    print(f"Epoch {epoch+1} loss: {loss.item()}")

torch.save(model.state_dict(), "model.pt")
