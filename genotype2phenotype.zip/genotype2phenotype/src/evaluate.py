import torch
from models import MultiModalModel

model = MultiModalModel()
model.load_state_dict(torch.load("model.pt"))
model.eval()
print("Model loaded and ready for inference.")
import torch
from models import MultiModalModel

model = MultiModalModel()
model.load_state_dict(torch.load("model.pt"))
model.eval()
print("Model loaded and ready for inference.")
