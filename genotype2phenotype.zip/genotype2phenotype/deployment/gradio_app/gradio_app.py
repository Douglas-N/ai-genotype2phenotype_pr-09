import gradio as gr
import torch
from src.models import MultiModalModel

model = MultiModalModel()
model.load_state_dict(torch.load("model.pt"))
model.eval()

def predict(expr, mut, comp):
    expr = torch.tensor(expr).float().unsqueeze(0)
    mut = torch.tensor(mut).float().unsqueeze(0)
    comp = torch.tensor(comp).float().unsqueeze(0)
    with torch.no_grad():
        out = model(expr, mut, comp)
    return float(out.item())

iface = gr.Interface(fn=predict, 
                     inputs=[gr.Dataframe(), gr.Dataframe(), gr.Dataframe()],
                     outputs="number",
                     title="Genotype2Phenotype Drug Response Predictor")
iface.launch()
