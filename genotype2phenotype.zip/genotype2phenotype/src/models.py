import torch
import torch.nn as nn

class MultiModalModel(nn.Module):
    def __init__(self, expr_dim=1000, mut_dim=500, comp_dim=256, hidden_dim=512, output_dim=1):
        super().__init__()
        # Expression branch
        self.expr_branch = nn.Sequential(
            nn.Linear(expr_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        # Mutation branch
        self.mut_branch = nn.Sequential(
            nn.Linear(mut_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        # Compound branch
        self.comp_branch = nn.Sequential(
            nn.Linear(comp_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        # Fusion
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim*3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )

    def forward(self, expr, mut, comp):
        e = self.expr_branch(expr)
        m = self.mut_branch(mut)
        c = self.comp_branch(comp)
        fused = torch.cat([e, m, c], dim=1)
        out = self.fusion(fused)
        return out
