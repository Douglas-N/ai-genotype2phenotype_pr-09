import torch
from models import MultiModalModel

def predict(expr, mut, comp, model_path="model.pt"):
    model = MultiModalModel()
    model.load_state_dict(torch.load(model_path))
    model.eval()
    with torch.no_grad():
        out = model(expr, mut, comp)
    return out
